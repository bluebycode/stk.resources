<p align="center">
  <img src="docs/images/stk-logo.png" width="200"/>
</p>


`stk` is a secure lightweight broker for remote shell access.

[![Build Status](https://travis-ci.org/vrandkode/stk.svg?branch=develop)](https://travis-ci.org/vrandkode/stk)



Designed for any browser.

**Usage**
---

```
go get 
```

**Installation Options**
---

1. Install with [`golang`]
    + `$ go get .`

2. Deploy from docker repository.


**Acknowledgements**
---

# @vrandkode